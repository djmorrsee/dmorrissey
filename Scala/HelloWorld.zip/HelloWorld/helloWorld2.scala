object helloWorld2 extends App {
	println("Hello, World!");
}
